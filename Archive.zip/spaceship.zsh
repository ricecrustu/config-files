# Dispaly time
SPACESHIP_TIME_SHOW=true

# Display username
SPACESHIP_USER_COLOR=#cba6f7

# Do not truncate path in repos
SPACESHIP_DIR_TRUNC_REPO=false

SPACESHIP_BATTERY_SHOW=false

SPACESHIP_EXIT_CODE_SHOW=true
