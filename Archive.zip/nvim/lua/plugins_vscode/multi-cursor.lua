return {
	"vscode-neovim/vscode-multi-cursor.nvim",
	event = "VeryLazy",
	cond = vim.g.vscode,
	opts = {},
}
