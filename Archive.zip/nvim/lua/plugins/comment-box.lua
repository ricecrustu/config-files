return {
	"LudoPinelli/comment-box.nvim",
	keys = {
		{ "<leader>Cb", mode = { "n", "v" }, "<Cmd>CBccbox<CR>", "Box Title Comment", { silent = true } },
		{
			"<leader>CB",
			mode = { "n", "v" },
			function()
				local input = vim.fn.input("Format: [l|r|c][l|r|c][n] (e.g., lr5)")
				if input then
					local char1, char2, num = string.match(input, "^([lrc])([lrc])(%d*)$")
					if char1 and char2 then
						local num_part = num ~= "" and num or ""
						vim.cmd(string.format("CB%s%sbox%s", char1, char2, num_part))
					else
						vim.notify("Invalid format! Use: [l|r|c][l|r|c][n] (e.g., lr5)", vim.log.levels.ERROR)
					end
				end
			end,
			"Box Title Comment with config",
			{ silent = true },
		},
		{ "<leader>Cl", mode = { "n", "v" }, "<Cmd>CBccline<CR>", "Line Title Comment", { silent = true } },
		{
			"<leader>CL",
			mode = { "n", "v" },
			function()
				local input = vim.fn.input("Format: [l|r|c][l|r|c][n] (e.g., lr5)")
				if input then
					local char1, char2, num = string.match(input, "^([lrc])([lrc])(%d*)$")
					if char1 and char2 then
						local num_part = num ~= "" and num or ""
						vim.cmd(string.format("CB%s%sline%s", char1, char2, num_part))
					else
						vim.notify("Invalid format! Use: [l|r|c][l|r|c][n] (e.g., lr5)", vim.log.levels.ERROR)
					end
				end
			end,
			"Line Title Comment with config",
			{ silent = true },
		},
		{ "<Leader>Cd", mode = { "n", "v" }, "<Cmd>CBd<CR>", "Delete Comment Box", { silent = true } },
	},
}
