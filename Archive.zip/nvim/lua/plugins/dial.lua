return {
	"monaqa/dial.nvim",
	event = "VeryLazy",
	config = function()
		vim.keymap.set("n", "<C-=>", require("dial.map").inc_normal(), { noremap = true })
		vim.keymap.set("n", "<C-->", require("dial.map").dec_normal(), { noremap = true })

		local augend = require("dial.augend")
		require("dial.config").augends:register_group({
			-- default augends used when no group name is specified
			default = {
				-- augend.integer.alias.decimal, -- nonnegative decimal number (0, 1, 2, 3, ...)
				augend.integer.alias.decimal_int, -- decimal integer (including negative number)
				augend.integer.alias.hex, -- nonnegative hex number  (0x01, 0x1a1f, etc.)
				augend.constant.alias.bool, -- boolean value (true <-> false)
				augend.date.alias["%Y/%m/%d"], -- date (2022/02/19, etc.)
				augend.date.alias["%m/%d/%Y"], -- date (02/19/2022, etc.)
				augend.date.alias["%Y-%m-%d"],
				augend.date.alias["%m/%d"],
				augend.date.alias["%H:%M"],
				augend.semver.alias.semver,

				-- f string toggle
				augend.user.new({
					find = require("dial.augend.common").find_pattern("[f]?[\"'][^\"']*[\"']"),
					add = function(text, addend, cursor)
						if text:match("^f['\"]") then
							text = text:sub(2) -- Remove 'f' prefix from f-string
						else
							text = "f" .. text -- Add 'f' prefix to make it an f-string
						end
						cursor = #text
						return { text = text, cursor = cursor }
					end,
				}),

				-- equal/inequal toggle
				augend.constant.new({
					elements = { "==", "!=", "<=", ">=" },
					word = false,
					cyclic = true,
				}),

				-- markdown todo list toggle
				augend.constant.new({
					elements = { "- [ ]", "- [/]", "- [x]" },
					word = false,
					cyclic = true,
				}),
			},
		})
	end,
}
