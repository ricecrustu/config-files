return {
	"fei6409/log-highlight.nvim",
	ft = "log",
	opts = {},
}
