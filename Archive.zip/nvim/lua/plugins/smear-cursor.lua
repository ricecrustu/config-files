return {
	"sphamba/smear-cursor.nvim",
	event = "VeryLazy",
	opts = {
		stiffness = 0.6,
		trailing_stiffness = 0.6,
		damping = 0.65,
		matrix_pixel_threshold = 0.5,
		smear_to_cmd = false,
	},
}
