return {
	"alex-popov-tech/store.nvim",
	enable = true,
	dependencies = { "OXY2DEV/markview.nvim" },
	cmd = "Store",
}
