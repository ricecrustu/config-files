---@class Utils
local M = {}

---Creates an augroup while clearing previous autocmds
---@param name string The name of the augroup
---@return number augroup_id The augroup id
function M.augroup(name)
	return vim.api.nvim_create_augroup(name, { clear = true })
end

return M
